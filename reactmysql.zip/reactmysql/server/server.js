import express from "express"
import mysql from "mysql"

const app = express();

const db= mysql.createConnection({
    host:"localhost",
    port:"3306" ,
    user:"root",
    password: "password",
    database: 'crud'
})
app.use(express.json());

app.get('/',(req, res) => {
    const sql = "select * from student";
    db.query(sql,(err,result)=> {
     if(err) return res.json({Message: err});
     return res.json(result);  
    })
})

// POST method to create a new student
app.post('/student', (req, res) => {
    const { studentid,studentname,studentemail } = req.body;
    const sql = "INSERT INTO student (studentid,studentname,studentemail) VALUES (?, ?, ?)";
    db.query(sql,[studentid,studentname,studentemail], (err, result) => {
        if (err) return res.json({ message: err });
        return res.json({ message: "Student created successfully" });
    });
});

app.listen(8002, () => {console.log("listening");

});

// DELETE method to delete a student
app.delete('/student/:studentid', (req, res) => {
    const studentId = req.params.studentid;

    const sql = "DELETE FROM student WHERE studentid = ?";

    db.query(sql, [studentId], (err, result) => {
        if (err) {
            return res.status(500).json({ message: err });
        }
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Student not found' });
        }
        return res.json({ message: 'Student deleted successfully' });
    });
});
// PUT method to update student data
app.put('/student/:studentid', (req, res) => {
    const studentId = req.params.studentid;
    const { studentname, studentemail } = req.body;
    
    if (!studentname && !studentemail) {
        return res.status(400).json({ message: 'No fields to update provided' });
    }

    let updateFields = [];
    let updateValues = [];

    if (studentname) {
        updateFields.push('studentname = ?');
        updateValues.push(studentname);
    }
    if (studentemail) {
        updateFields.push('studentemail = ?');
        updateValues.push(studentemail);
    }

    const sql = `UPDATE student SET ${updateFields.join(', ')} WHERE studentid = ?`;

    db.query(sql, [...updateValues, studentId], (err, result) => {
        if (err) return res.json({ message: err });
        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'Student not found' });
        }
        return res.json({ message: 'Student updated successfully' });
    });
});
